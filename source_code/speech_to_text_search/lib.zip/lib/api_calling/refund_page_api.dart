
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:speech_to_text_search/Service/api_constants.dart';
import 'package:speech_to_text_search/Service/is_login.dart';
import 'package:speech_to_text_search/Service/result.dart';
import 'package:speech_to_text_search/models/quickSellSuggestionModel.dart';


typedef void NetworkResponseHandler(Result result);

class RefundPageApi {

 static Future<void> fetchDataAndAssign(String itemName, NetworkResponseHandler networkResponseHandler) async {
    String? token;

    try {
      token = await APIService.getToken();
      final response = await http.get(
        Uri.parse('$baseUrl/product-suggesstions?item_name=$itemName'),
        headers: {
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 201) {
        final Map<String, dynamic> responseData = json.decode(response.body);
        print(responseData);
        if (responseData['status'] == 'success') {
          Map<String, dynamic> decoded = json.decode(response.body);
          QuickSellSuggestionModel data = QuickSellSuggestionModel.fromJson(decoded);
          networkResponseHandler(Result.success(data));
        }
        else {
          print('API call failed with status: ${responseData['status']}. Response body: ${response.body}');
        }
      } else {
        print('Failed to load data. Response body: ${response.body}');
      }
    }
    catch(e) {
      print('Error fetching data: $e');
    }
  }

  static   Future<List<String>> getQuantityUnits(String itemId, String token) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/related-units'),
        headers: {
          'Authorization': 'Bearer $token',
        },
        body: {
          'item_id': itemId,
        },
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = json.decode(response.body);

        if (responseData['status'] == 'success') {
          final List<dynamic> units = responseData['units'];
          return units.cast<String>().toList();
        } else {
          // Handle failed response
          print('API call failed with message: ${responseData['message']}');
          return [];
        }
      } else {
        // Handle other HTTP status codes
        print('HTTP request failed with status code: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      // Handle exceptions
      print('Error occurred: $e');
      return [];
    }
  }

}