// void addProductTable(String itemName, double finalQuantity, String unit, double salePrice) {
//   double amount = salePrice * finalQuantity; // Calculate the amount
//   setState(() {
//     itemForBillRows.add({
//       'itemId': itemId,
//       'itemName': itemName,
//       'quantity': finalQuantity,
//       'rate': salePrice,
//       'selectedUnit': unit,
//       'amount': amount,
//       'isDelete': 0,
//       'isRefund': 0,
//     });
//   });
//   // Add the product to the list
// }

// void addProductRefundTable(String itemName, double finalQuantity, String unit, double salePrice) {
//   double amount = salePrice * finalQuantity; // Calculate the amount
//   setState(() {
//     itemForBillRows.add({
//       'itemId': itemId,
//       'itemName': itemName,
//       'quantity': finalQuantity,
//       'rate': salePrice,
//       'selectedUnit': unit,
//       'amount': amount * -1,
//       'isDelete': 0,
//       'isRefund': 1,
//     });
//   });
//   // Add the product to the list
// }
